# Matrix_7-Segment_LED_Backpack_Raspberry_Pi

Code to accompany this tutorial:
https://learn.adafruit.com/matrix-7-segment-led-backpack-with-the-raspberry-pi/
